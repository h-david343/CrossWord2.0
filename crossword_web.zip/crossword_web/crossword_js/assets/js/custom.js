$('.input-words-btn').click(() => {
    let quantity = $('.input-words-quantity').val()
    if (quantity > 15 || quantity < 2) {
        $('.input-words-quantity').addClass('input-quantity-err')
    }
    else {
        let inps = document.querySelectorAll('.words-inp')
        $('.input-words-quantity').removeClass('input-quantity-err')
        if (inps.length == 0) {
            document.querySelector('.inputs-words').innerHTML = ' '
            for (let i = 1; i <= quantity; i++) {
                document.querySelector('.inputs-words').innerHTML += '<div class="col-lg-12 col-sm-12 col-md-11 p-0 mt-1 input-words-div"><div class="col-lg-1 col-md-1 col-sm-1 col-1">' + i + '</div><input type="text" class="col-lg-10 col-md-10 col-sm-10 col-10 words-inp"></div>'
            }
        }
        else {
            let inps_vals = []
            for (let i = 0; i < inps.length; i++) {
                inps_vals[i] = inps[i].value
            }
            document.querySelector('.inputs-words').innerHTML = ' '
            for (let i = 1; i <= quantity; i++) {
                document.querySelector('.inputs-words').innerHTML += '<div class="col-lg-12 col-sm-12 col-md-11 p-0 mt-1 input-words-div"><div class="col-lg-1 col-md-1 col-sm-1 col-1">' + i + '</div><input type="text" class="col-lg-10 col-md-10 col-sm-10 col-10 words-inp"></div>'
            }
            let inpVals = document.querySelectorAll('.words-inp')
            if (inpVals > inps_vals) {
                for (let i = 0; i < inpVals.length; i++) {
                    inpVals[i].value = inps_vals[i]
                }
            }
            else {
                for (let i = 0; i < inps_vals.length; i++) {
                    inpVals[i].value = inps_vals[i]
                }
            }
        }
        document.querySelector('.create-btn-div').innerHTML = '<button class="create-btn mt-5 mr-3">Create</button>'
    }
    $('.create-btn').click(() => {
        let inpVals = document.querySelectorAll('.words-inp')
        let vals = []
        for (let i = 0; i < inpVals.length; i++) {
            vals[i] = inpVals[i].value
        }
        $('.crossword').css({
            "display": "flex"
        })

        $.ajax({
            url: "http://localhost:8000/data",
            type: 'POST',
            contentType: "application/json",
            crossDomain: true,
            data: JSON.stringify(vals),
            success: function (res) {
                $('.start-div').css({
                    "top": "-100%"
                })

                if (res.length) {
                    $('body').css({
                        "background-image": "none"
                    })
                    var option = 0
                    filling(option)
                    function filling(a) {
                        let quantity_inp = document.querySelectorAll('.words-inp').length

                        let max_x = 0
                        let max_y = 0
                        $('.number-of-crossword').html(`${a + 1}/${res.length}`)
                        for (let i = 0; i < quantity_inp; i++) {
                            if (res[a].words[i].direction == 'Down') {
                                if (res[a].words[i].position.y + res[a].words[i].value.length > max_x) {
                                    max_x = res[a].words[i].position.y + res[a].words[i].value.length
                                }
                            }
                            else if (res[a].words[i].direction == 'Right') {
                                if (res[a].words[i].position.x + res[a].words[i].value.length > max_y) {
                                    max_y = res[a].words[i].position.x + res[a].words[i].value.length
                                }
                            }
                        }
                        let crosswords_div_width = document.querySelector('.crosswords').offsetWidth / max_y
                        let crosswords_div_height = document.querySelector('.crosswords').offsetHeight / max_x
                        var crossword_letters = []
                        for (let i = 0; i < max_x; i++) {
                            crossword_letters[i] = []
                            for (let j = 0; j < max_y; j++) {
                                crossword_letters[i][j] = `<div class="crassword-letter letter-${i}-${j}" style="width:${crosswords_div_width}px;height:${crosswords_div_height}px;"></div>`
                            }
                        }
                        for (let i = 0; i < quantity_inp; i++) {
                            if (res[a].words[i].direction == 'Down') {
                                let r = 0
                                for (let k = res[a].words[i].position.y; k < res[a].words[i].value.length + res[a].words[i].position.y; k++) {
                                    crossword_letters[k][res[a].words[i].position.x] = `<div class="crassword-letter letter-${k}-${res[a].words[i].position.x}" style="width:${crosswords_div_width}px;height:${crosswords_div_height}px;">${res[a].words[i].value[r]}</div>`
                                    r++
                                }
                            }
                            else if (res[a].words[i].direction == 'Right') {
                                let r = 0
                                for (let k = res[a].words[i].position.x; k < res[a].words[i].value.length + res[a].words[i].position.x; k++) {
                                    crossword_letters[res[a].words[i].position.y][k] = `<div class="crassword-letter letter-${res[a].words[i].position.y}-${k}" style="width:${crosswords_div_width}px;height:${crosswords_div_height}px;">${res[a].words[i].value[r]}</div>`
                                    r++
                                }
                            }
                        }
                        document.querySelector('.crosswords').innerHTML = ''
                        for (let i = 0; i < max_x; i++) {
                            document.querySelector('.crosswords').innerHTML += crossword_letters[i].join('')
                        }
                        if (document.querySelector('.anim-check').checked == true) {
                            var quantity_animation = 0
                            for (let i = 0; i < max_x; i++) {
                                for (let j = 0; j < max_y; j++) {
                                    let a = $(`.letter-${i}-${j}`).html()
                                    let symvols = '1234567890!@#$%^&*()-_=+[{:;"/?.>,<\|~}]'
                                    if ($(`.letter-${i}-${j}`).html() != ``) {
                                        let anim1 = setInterval(() => {
                                            if (quantity_animation == 5) {
                                                $(`.letter-${i}-${j}`).html(a)
                                                quantity_animation = 0
                                                clearTimeout(anim1)
                                            }
                                            else {
                                                $(`.letter-${i}-${j}`).html(`${symvols[Math.floor(Math.random() * symvols.length)]}`)
                                                quantity_animation++
                                            }
                                        }, 100);
                                        console.log($(`.letter-${i}-${j}`).html())
                                    }
                                    // if (i == j) {
                                    //     let anim2 = setInterval(() => {
                                    //         if (quantity_animation == 5) {
                                    //             $(`.letter-${i}-${j}`).html(a)
                                    //             quantity_animation = 0
                                    //             clearTimeout(anim2)
                                    //         }
                                    //         else {
                                    //             $(`.letter-${i}-${j}`).html(`${symvols[Math.floor(Math.random() * symvols.length)]}`)
                                    //             quantity_animation++
                                    //         }
                                    //     }, 100);
                                    // }
                                }
                            }
                        }
                        $('.next-prev-buttons').show(500)
                        if (a == 0) {
                            $('.next-crossword-btn').css({
                                "display": "flex"
                            })
                            $('.previous-crossword-btn').css({
                                "display": "none"
                            })
                        }
                        else if (a != 0 && a + 1 != res.length) {
                            $('.previous-crossword-btn').css({
                                "display": "flex"
                            })
                            $('.next-crossword-btn').css({
                                "display": "flex"
                            })
                        }
                        if (a + 1 == res.length) {
                            $('.next-crossword-btn').css({
                                "display": "none"
                            })
                        }
                        $('.edit-but').click(() => {
                            $('.crossword').css({
                                "display": "none"
                            })
                            $('.start-div').css({
                                "top": "0"
                            })
                        })
                        $('.next-crossword-btn').click(() => {
                            option++
                            $('.crosswords').css({
                                "left": "-100%"
                            })
                            setTimeout(() => {
                                document.querySelector('.crosswords').remove()
                                document.querySelector('.crossword').innerHTML += `<div class="crosswords"></div>`
                                $('.crosswords').css({
                                    "left": "100%"
                                })
                                filling(option)
                                $('.crosswords').css({
                                    "left": "5%"
                                })
                            }, 300)
                        })
                        $('.previous-crossword-btn').click(() => {
                            option--
                            $('.crosswords').css({
                                "left": "100%"
                            })
                            setTimeout(() => {
                                document.querySelector('.crosswords').remove()
                                document.querySelector('.crossword').innerHTML += `<div class="crosswords"></div>`
                                $('.crosswords').css({
                                    "left": "-100%"
                                })
                                filling(option)
                                $('.crosswords').css({
                                    "left": "5%"
                                })
                            }, 300)
                        })
                    }
                }
                else {
                    let words = '<ol>'
                    for (let i = 0; i < vals.length; i++) {
                        words += `<li>${vals[i]}</li>`
                    }
                    words += '</ol>'
                    $('.crosswords').html(`<div class='crossword-error'><div style="width:100%; text-align:center;">It is impossible to create a crossword with the following words</div>${words}<button class='try-again-but'>Try again</button></div>`)
                    $('.try-again-but').click(() => {
                        $('.crossword').css({
                            "display": "none"
                        })
                        $('.start-div').css({
                            "top": "0"
                        })
                    })
                }
            }
        })
    })
})
