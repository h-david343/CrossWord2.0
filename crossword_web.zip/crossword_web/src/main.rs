#[macro_use]
extern crate rocket;

use crossword_generator::crossword::Crossword;
use crossword_generator::generator::{CrosswordGenerationRequest, CrosswordGenerator, CrosswordGeneratorSettings};
use crossword_generator::word::Word;
use rocket::futures::StreamExt;
use rocket::{fs::NamedFile, tokio::sync::Mutex};
use rocket::response::status::NotFound;
use std::path::PathBuf;
use rocket::serde::{Deserialize, json::Json};


#[post("/data", format = "application/json", data = "<words>")]
async fn words_data(words: Json<Vec<String>>) -> Json<Vec<Crossword<u8, String>>>
{   
    let mut generator = CrosswordGenerator::<u8, Vec<u8>>::default();
    generator.words = words.0.into_iter().map(|s| Word::new(<String as AsRef<[u8]>>::as_ref(&s.to_lowercase()).to_owned(), None)).collect();
        
    let str = generator.crossword_stream();
    str.request_crossword(CrosswordGenerationRequest::Endless).await;
    let crosswords = str.map(|cw| cw.convert_to::<_>(|w| String::from_utf8(w).unwrap())).collect::<Vec<Crossword<u8, _>>>().await;
    
    Json(crosswords)
}

async fn get_index() -> Result<NamedFile, NotFound<String>> 
{
    NamedFile::open("crossword_js/index.html")
        .await
        .map_err(|e| NotFound(e.to_string()))
}

#[get("/<path..>")]
async fn index(path: PathBuf) -> Result<NamedFile, NotFound<String>>
{
    let path = PathBuf::from("./crossword_js/").join(path);
    match NamedFile::open(path).await 
    {
        Ok(f) => Ok(f),
        Err(_) => get_index().await,
    }
}

#[launch]
fn rocket() -> _ 
{
    rocket::build()
        .mount("/", routes![index, words_data])
}